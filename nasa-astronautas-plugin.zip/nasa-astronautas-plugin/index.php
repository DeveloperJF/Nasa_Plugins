<? php
// silence is golden

?>