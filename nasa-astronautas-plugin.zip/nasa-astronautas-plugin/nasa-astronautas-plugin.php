<?php
/*
Plugin Name: NASA_astronautas
Plugin URI: https://plugindejuan.com
Descripcion: Plugin que tiene datos de los diferentes astronautas que se quieren vincular a la NASA
Version: 0.1.0
Author: Juan Fernando Jiménez
Author: https://paginadejuan.com
License: MIT
License URI: https://opensource.org/licenses/MIT
Text domain: nasa-autronautas-plugin
shortcode: [Nasa_Candidato_form]
*/

// Cuando se activa el plugin se crea la tabla del mismo si no existe
register_activation_hook(__FILE__, 'nasaCandidato');

// Realiza las acciones necesarias cuando el plugin se activa
function nasaCandidato()
{

    global $wpdb; // Este objeto global nos permite trabajar con la BD de WP

    // Crea la tabla si no existe
    $tabla_candidatos = $wpdb->prefix . 'nasa_';
    $charset_collate = $wpdb->get_charset_collate();

    // Prepara la consulta que vamos a lanzar para crear la tabla
    $query = "CREATE TABLE IF NOT EXISTS $tabla_candidatos(
        id              int(255) auto_increment not null,
        nombre          varchar(255) not null,
        edad            int(200) not null,
        genero          char(255) not null,
        correo          varchar(100) not null,
        motivo          varchar(255)not null,
        tiempo          varchar(255)not null,
        acceptance      varchar(4) not null,
        ip              varchar(300),
        created_at      datetime not null,
        CONSTRAINT pk_tabla_candidatos PRIMARY KEY(id),
        CONSTRAINT uq_correo UNIQUE(correo)
    ) $charset_collate";

    /*
    La función dbDelta que nos permite crear tablas de manera segura se define en el fichero upgrade.php que se incluye a continuación
    */
    include_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($query);
}

add_shortcode('Nasa_Candidato_form', 'Nasa_Candidato_form');

// Crea y procesa el formulario que rellenan los candidatos
function Nasa_Candidato_form()
{

    global $wpdb;


    if (
        !empty($_POST)
        && $_POST['nombre'] != ''
        && $_POST['edad'] != ""
        && $_POST['genero'] != ""
        && is_email($_POST['correo'])
        && $_POST['motivo'] != ""
        && $_POST['tiempo'] != ""
        && $_POST['acceptance'] == '1'
    ) {
        $tabla_candidatos = $wpdb->prefix . 'nasa_';

        $nombre = sanitize_text_field($_POST['nombre']);
        $edad = (int)$_POST['edad'];
        $genero = sanitize_text_field($_POST['genero']);
        $correo = sanitize_email($_POST['correo']);
        $motivo = sanitize_text_field($_POST['motivo']);
        $tiempo = sanitize_text_field($_POST['tiempo']);
        $acceptance = (int)$_POST['acceptance'];
        $ip = Nasa_Obtener_IP_usuario();
        $created_at = date('Y-m-d H:i:s');

        $wpdb->insert($tabla_candidatos, array(
            'nombre' => $nombre,
            'edad' => $edad,
            'genero' => $genero,
            'correo' => $correo,
            'motivo' => $motivo,
            'tiempo' => $tiempo,
            'acceptance' => $acceptance,
            'ip' => $ip,
            'created_at' => $created_at,
        ));
    }

    // Carga esta hoja de estilo para poner más bonito el formulario
    wp_enqueue_style('css_nasa_', plugins_url('style.css', __FILE__));
    ob_start();
?>

    <form action="<?php get_the_permalink(); ?>" method="POST" id="form_candidato" class="formulario">
        <?php wp_nonce_field('graba_candidato', 'candidato_nonce'); ?>
        <div class="form-input nombre">
            <label for="nombre_completo">Nombre Completo:</label>
            <input type="text" name="nombre" id="nombre_completo" value="" required />
        </div>
        <div class="form-input edad">
            <label for="edad">Edad</label>
            <input type="number" name="edad" id="edad" required />
        </div>
        <div class="form-input genero">
            <h6>Género:</h6>
            <input type="radio" name="genero" id="femenino" value="femenino" checked />
            <label for="genero">Femenino</label>
            <input type="radio" name="genero" id="masculino" value="masculino" />
            <label for="genero">masculino</label>
            <input type="radio" name="genero" id="otro" value="Otro" />
            <label for="genero">Otro</label>
        </div>
        <div class="clearflix"></div>
        <div class="form-input correo">
            <label for="correo">Correo Electrónico:</label>
            <input type="email" name="correo" id="correo" required />
        </div>
        <div class="form-input motivo">
            <label for="motivo">Motivo para ir a la luna:</label>
            <textarea name="motivo" id="motivo" cols="30" rows="10"></textarea>
        </div>
        <div class="form-input tiempo">
            <label for="contacto">Última vez que tuvo contacto con extraterrestres:</label><br />
            <input type="radio" name="tiempo" value="Menos de 1 mes"> Menos de 1 mes<br />
            <input type="radio" name="tiempo" value="Más de 1 mes y menor a 6 meses"> Más de 1 mes y menor a 6 meses<br />
            <input type="radio" name="tiempo" value="Más de 6 meses y menor a 12 meses"> Más de 6 meses y menor a 12 meses<br />
            <input type="radio" name="tiempo" value="Más de 1 año y menor a 3 años"> Más de 1 año y menor a 3 años<br />
            <input type="radio" name="tiempo" value="Más de 3 años y menor a 5 años"> Más de 3 años y menor a 5 años<br />
            <input type="radio" name="tiempo" value="Mayor a 5 años"> Mayor a 5 años<br />
        </div>
        <div class="form-input permisos">
            <label for="acceptance">La información facilitada se tratará con respeto y la finalidad es la participación en el proceso de selección de los candidatos para el ingreso a la NASA.</label>
            <div class="clearflix"></div>
            <input type="checkbox" id="acceptance" name="acceptance" value="1" required /> Entiendo y acépto las condiciones
        </div>

        <div class="form-input button">
            <input type="submit" value="Enviar" />
        </div>
    </form>

<?php
    return ob_get_clean();
}

add_action("admin_menu", "Nasa_Candidato_menu");


// Agrega el menú del plugin al formulario de WordPress
function Nasa_Candidato_menu()
{
    add_menu_page("Formulario Candidatos", "NASA clientes", "manage_options", "nasa_candidato_menu", "Nasa_Candidato_admin", "dashicons-feedback", 75);
}

function Nasa_Candidato_admin()
{
    global $wpdb;
    $tabla_candidatos = $wpdb->prefix . 'nasa_';
    $nasa_ = $wpdb->get_results("SELECT * FROM $tabla_candidatos");
    echo '<div class="wrap"><h1>Lista de candidatos</h1>';
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th width="20%">Nombre</th><th width="5%">Edad</th>';
    echo '<th width="8%">Género</th><th width="20%">Correo</th><th width="30%">Motivo</th><th>Tiempo</th>';
    echo '</tr></thead>';
    echo '<tbody id="the-list">';

    foreach ($nasa_ as $candidato) {
        $nombre = esc_textarea($candidato->nombre);
        $edad = (int) $candidato->edad;
        $genero = esc_textarea($candidato->genero);
        $correo = esc_textarea($candidato->correo);
        $motivo = esc_textarea($candidato->motivo);
        $tiempo = esc_textarea($candidato->tiempo);

        echo "<tr><td>$nombre</td>";
        echo "<td>$edad</td><td>$genero</td><td>$correo</td><td>$motivo</td>";
        echo "<td>$tiempo</td></tr>";
    }
    echo '</tbody></table></div>';
}

/*
 * Devuelve la IP del usuario que está visitando la página
 */
function Nasa_Obtener_IP_usuario()
{
    foreach (array(
        'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED',
        'REMOTE_ADDR'
    ) as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (array_map('trim', explode(',', $_SERVER[$key])) as $ip) {
                if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                    return $ip;
                }
            }
        }
    }
}
